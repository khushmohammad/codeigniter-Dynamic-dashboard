  
    <script src="<?php echo site_url(); ?>assets/js/jquery-3.4.1.min.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo site_url(); ?>assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo site_url(); ?>assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="<?php echo site_url(); ?>assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo site_url(); ?>assets/js/custom.js"></script>

</body>


</html>