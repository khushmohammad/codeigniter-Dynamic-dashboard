    <script src="<?php echo site_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo site_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
  
    <script src="<?php echo site_url(); ?>assets/vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo site_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo site_url(); ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo site_url(); ?>assets/js/sb-admin-datatables.min.js"></script>
   

</body>


</html>