    <script src="<?php echo site_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
  
   

</body>


</html>