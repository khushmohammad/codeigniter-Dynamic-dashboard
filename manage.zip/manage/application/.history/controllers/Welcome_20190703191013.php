<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	public function index()  
    {  
        $this->login();  
    }  

	public function Login()  
    {  
		$data['username'] = $this->session->userdata('username');
		
	
		$this->load->view('header'); 
        $this->load->view('Login',$data); 		 
        $this->load->view('footer'); 
   
	
	
		

    }  
    public function Dashboard()  
    {  
		if($this->input->post('login'))
		{
		$u=$this->input->post('username');
		$p=$this->input->post('password');
		
		$que=$this->db->query("select * from mn_user where username='".$u."' and password='$p'");
		$row = $que->num_rows();
		if($row)
		{
		redirect('User/dashboard');
		}
		else
		{
		$data['error']="<h3 style='color:red'>Invalid login details</h3>";
		} 
		}
		$this->load->view('login',@$data); 
		}
      
    public function logout()  
    {  
        //removing session  
		$this->session->unset_userdata('user'); 
		redirect('welcome/login'); 
         
    }  
	
	
}






























		
		

    


