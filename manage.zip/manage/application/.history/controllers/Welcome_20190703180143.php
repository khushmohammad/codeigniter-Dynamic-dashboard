<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()  
    {  
        $this->login();  
	}  
	public function login()  
    {  
		$this->load->view('header'); 
        $this->load->view('Login');  
        $this->load->view('footer');  
		
    }  
	
}






























		
		

    


