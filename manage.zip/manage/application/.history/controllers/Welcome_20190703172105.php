<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function Login()
	{
		$this->load->view('header');
		$this->load->view('Login');
		$this->load->view('footer');
		
	}

	public function Dashboard()  
    {  
        $user = $this->input->post('username');  
        $pass = $this->input->post('password');  
        if ($user=='juhi' && $pass=='123')   
        {  
            //declaring session  
			$this->session->set_userdata(array('user'=>$user)); 
			$this->load->view('header');
			$this->load->view('Template/Dashboard_view');
			$this->load->view('footer'); 
	
            
        }  
        else{  
            $data['error'] = 'Your Account is Invalid';  
            $this->index();  
        }  
    }  
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('user');  
		$this->Login();
    }  
  
} 

