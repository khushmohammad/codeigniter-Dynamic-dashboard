<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()  
    {  
        $this->login();  
	}  
	public function login()  
    {  
		$this->load->view('header'); 
        $this->load->view('Login');  
        $this->load->view('footer');  
		
	}  
	
	public function signin()  
    {  
		$this->load->view('header'); 
        $this->load->view('Template/Dashboard_view');  
        $this->load->view('footer');
	} 
	
	public function login_action()  
    {  
        $this->load->helper('security');  
        $this->load->library('form_validation');  
  
        $this->form_validation->set_rules('username', 'Username:', 'required|trim|xss_clean|callback_validation');  
        $this->form_validation->set_rules('password', 'Password:', 'required|trim');  
  
        if ($this->form_validation->run())   
        {  
            $data = array(  
                'username' => $this->input->post('username'),  
                'currently_logged_in' => 1  
                );    
                    $this->session->set_userdata($data);  
                redirect('Main/data');  
        }   
        else {  
            $this->load->view('login_view');  
        }  
    }  
	
}






























		
		

    


