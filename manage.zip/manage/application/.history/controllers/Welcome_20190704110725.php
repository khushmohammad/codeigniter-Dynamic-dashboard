<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	function login()  
	{  
		 //http://localhost/tutorial/codeigniter/main/login  
		 $data['title'] = 'manage'; 
		 $this->load->view('header'); 
		 $this->load->view("login", $data); 
		 $this->load->view('footer'); 

	}  
	function login_validation()  
	{  
		 $this->load->library('form_validation');  
		 $this->form_validation->set_rules('username', 'Username', 'required');  
		 $this->form_validation->set_rules('password', 'Password', 'required');  
		 if($this->form_validation->run())  
		 {  
			  //true  
			  $username = $this->input->post('username');  
			  $password = $this->input->post('password');  
			  //model function  
			  $this->load->model('ManageModel');  
			  if($this->ManageModel->can_login($username, $password))  
			  {  
				   $session_data = array(  
						'username'     =>     $username  
				   );  
				   $this->session->set_userdata($session_data);  
				   redirect(base_url() . 'welcome/enter');  
			  }  
			  else  
			  {  
				   $this->session->set_flashdata('error', 'Invalid Username and Password');  
				   redirect(base_url() . 'welcome/login');  
			  }  
		 }  
		 else  
		 {  
			  //false  
			  $this->login();  
		 }  
	}  
	function enter(){  
		 if($this->session->userdata('username') != '')  
		 {  
			  echo '<h2>Welcome - '.$this->session->userdata('username').'</h2>';  
			  echo '<label><a href="'.base_url

().'welcome/logout">Logout</a></label>';  
		 }  
		 else  
		 {  
			  redirect(base_url() . 'welcome/login');  
		 }  
	}  
	function logout()  
	{  
		 $this->session->unset_userdata('username');  
		 redirect(base_url() . 'welcome/login');  
	}  


//
// 	public function login()
// 	{



	 
		
// 		if($this->input->post('login'))
// 		{
// 			$username=$this->input->post('username');
// 			$password=$this->input->post('password');
			
// 			$que=$this->db->query("select * from mn_user where username='".$username."' and password='$password'");
			
// 			$row = $que->num_rows();
			
// 		$data = 	$this->session->set_userdata(array('username'=>$username)) ;
			
// 			if(isset($data))
// 			{
		 	
// 			redirect('welcome/dashboard');
// 			}
// 			else
// 			{
// 		$data['error']="<h3 style='color:red'>Invalid login details</h3>";
// 			}	
// 		}
// 		$this->load->view('header'); 
//         $this->load->view('Login',@$data); 		 
//         $this->load->view('footer'); 	
// 	}
	
	

	
	 
   
	
	
		

  
    public function Dashboard()  
    {  
      
            //declaring session  
         //   $this->session->set_userdata(array('user'=>$u));  
			$this->load->view('header');
            $this->load->view('template/dashboard_view'); 
            $this->load->view('footer'); 	
      
    }  
    public function logout()  
    {  
        //removing session  
		$this->session->unset_userdata('user'); 
		redirect('welcome/login'); 
         
    }  
	
	
}






























		
		

    


