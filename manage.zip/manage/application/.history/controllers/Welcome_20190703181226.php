<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()  
    {  
		$this->load->view('header'); 
        $this->load->view('Login'); 		 
        $this->load->view('footer');  

    }  
    public function Dashboard()  
    {  
        $user = $this->input->post('user');  
        $pass = $this->input->post('pass');  
        if ($user=='juhi' && $pass=='123')   
        {  
            //declaring session  
            $this->session->set_userdata(array('user'=>$user));  
			$this->load->view('header');
            $this->load->view('template/dashboard_view'); 
            $this->load->view('footer'); 			
        }  
        else{  
			$data['error'] = 'Your Account is Invalid';  
			$this->load->view('header'); 
       		 $this->load->view('Login', $data); 		 
        	$this->load->view('footer'); 
           
        }  
    }  
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('user');  
        redirect("Welcome");  
    }  
	
	
}






























		
		

    


