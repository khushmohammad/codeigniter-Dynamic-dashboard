<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model('ManageModel');
    }

	function index(){

		$this->login();
	}
	
	function login()  
	{  
		 //http://localhost/tutorial/codeigniter/main/login  
		 $data['title'] = 'manage'; 
		 $this->load->view('header'); 		 
		 $this->load->view("login", $data); 
		 $this->load->view('footer'); 

	}  
	function login_validation()  
	{  
		 $this->load->library('form_validation');  
		 $this->form_validation->set_rules('username', 'Username', 'required');  
		 $this->form_validation->set_rules('password', 'Password', 'required');  
		 if($this->form_validation->run())  
		 {  
			  //true  
			  $username = $this->input->post('username');  
			  $password = $this->input->post('password');  
			  //model function  
			  
			  if($this->ManageModel->can_login($username, $password))  
			  {  
				   $session_data = array(  
						'username'     =>     $username  
				   );  
				   $this->session->set_userdata($session_data);  
				   redirect(base_url() . 'welcome/Dashboard');  
			  }  
			  else  
			  {  
				   $this->session->set_flashdata('error', 'Invalid Username and Password');  
				   redirect(base_url() . 'welcome/login');  
			  }  
		 }  
		 else  
		 {  
			  //false  
			  $this->login();  
		 }  
	}  
	function Dashboard(){  
		 if($this->session->userdata('username') != '')  
		 {  
			
			$this->load->view('header');
			$this->load->view('navbar');

			$this->load->view('template/dashboard_view'); 
			$this->load->view('footer'); 
		 }  
		 else  
		 {  
			  redirect(base_url() . 'welcome/login');  
		 }  
	}  
	function logout()  
	{  
		 $this->session->unset_userdata('username');  
		 redirect(base_url() . 'welcome/login');  
	}  


///Part1 section 

				



	function Part1(){  
		if($this->session->userdata('username') != '')  
		{  
		   
		   $this->load->view('header');
		   $this->load->view('navbar');
		   $this->load->view('part1/Part1_view'); 
		   $this->load->view('footer'); 
		}  
		else  
		{  
			 redirect(base_url() . 'welcome/login');  
		}  
   } 
  
 
   function part_data(){
	$data=$this->ManageModel->product_list();
	echo json_encode($data);
}

function save_data(){
	$data=$this->ManageModel->save_product();
	echo json_encode($data);
}

function update(){
	$data=$this->ManageModel->update_product();
	echo json_encode($data);
}

function delete(){
	$data=$this->ManageModel->delete_product();
	echo json_encode($data);
}

/////part1 end section	
}






























		
		

    


