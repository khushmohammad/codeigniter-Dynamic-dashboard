<?php
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class Managemodel extends CI_Model
{

    function login($username, $password)
    {
        return $username == 'pmk' && $password == 'lab';
    }

}