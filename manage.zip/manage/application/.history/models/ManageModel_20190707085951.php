<?php
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class Managemodel extends CI_Model
{
           
    function can_login($username, $password)  
    {  
         $this->db->where('username', $username);  
         $this->db->where('password', $password);  
         $query = $this->db->get('mn_user');  
         //SELECT * FROM mn_users WHERE username = '$username' AND password = '$password'  
         if($query->num_rows() > 0)  
         {  
              return true;  
         }  
         else  
         {  
              return false;       
         }  
    }  

    

    function product_list(){


        $this->db->select('*');
    $this->db->from('mn_part1');
    $this->db->limit($rowperpage, $rowno);  
    $query = $this->db->get();
 
    // return $query->result_array();
    //  $hasil=$this->db->get('mn_part1');
    //  return $hasil->result();

 }
 function save_product(){
     $data = array(
             'name'  => $this->input->post('name'), 
             'gender'  => $this->input->post('gender'), 
             'Part' => $this->input->post('Part'), 
         );
     $result=$this->db->insert('mn_part1',$data);
     return $result;
 }

 function update_part1(){
    $id=$this->input->post('id');
    $name=$this->input->post('name');
    $gender=$this->input->post('gender');
    $Part=$this->input->post('Part');


    $this->db->set('name', $name);
    $this->db->set('gender', $gender);
    $this->db->set('Part', $Part);

    $this->db->where('id', $id);
    $result=$this->db->update('mn_part1');
    return $result;
}

 function delete_part1(){
    $id=$this->input->post('id');
    $this->db->where('id', $id);
    $result=$this->db->delete('mn_part1');
    return $result;
}
public function information($id) {
    $q = $this->db->select('*')->from('mn_part1')->where('id',$id)->get();
    return $q->result();
    }
///part1 model start
    
}