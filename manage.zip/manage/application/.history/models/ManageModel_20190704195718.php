<?php
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class Managemodel extends CI_Model
{

    function can_login($username, $password)  
    {  
         $this->db->where('username', $username);  
         $this->db->where('password', $password);  
         $query = $this->db->get('mn_user');  
         //SELECT * FROM mn_users WHERE username = '$username' AND password = '$password'  
         if($query->num_rows() > 0)  
         {  
              return true;  
         }  
         else  
         {  
              return false;       
         }  
    }  

    

    function product_list(){
     $hasil=$this->db->get('mn_part1');
     return $hasil->result();

 }
 function save_product(){
     $data = array(
             'product_code'  => $this->input->post('product_code'), 
             'product_name'  => $this->input->post('product_name'), 
             'product_price' => $this->input->post('price'), 
         );
     $result=$this->db->insert('product',$data);
     return $result;
 }



    ///part1 model start
    
}