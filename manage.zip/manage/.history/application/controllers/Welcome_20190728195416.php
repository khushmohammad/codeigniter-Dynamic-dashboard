<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
        parent::__construct();
		$this->load->model('ManageModel');
		$this->load->library('form_validation');  
		
    }

	function index(){

		$this->login();
	}
	
	function login()  
	{  
		 //http://localhost/tutorial/codeigniter/main/login  
		 $data['title'] = 'manage'; 
		 $this->load->view('header'); 		 
		 $this->load->view("login", $data); 
		 $this->load->view('footer'); 

	}  
	function login_validation()  
	{  
		 $this->form_validation->set_rules('username', 'Username', 'required');  
		 $this->form_validation->set_rules('password', 'Password', 'required');  
		 if($this->form_validation->run())  
		 {  
			  //true  
			  $username = $this->input->post('username');  
			  $password = $this->input->post('password');  
			  //model function  
			  
			  if($this->ManageModel->can_login($username, $password))  
			  {  
				   $session_data = array(  
						'username'     =>     $username  
				   );  
				   $this->session->set_userdata($session_data);  
				   redirect(base_url() . 'welcome/Dashboard');  
			  }  
			  else  
			  {  
				   $this->session->set_flashdata('error', 'Invalid Username and Password');  
				   redirect(base_url() . 'welcome/login');  
			  }  
		 }  
		 else  
		 {  
			  //false  
			  $this->login();  
		 }  
	}  
	function Dashboard(){  
		 if($this->session->userdata('username') != '')  
		 {  
			
			$this->load->view('header');
			$this->load->view('navbar');

			$this->load->view('template/dashboard_view'); 
			$this->load->view('footer'); 
		 }  
		 else  
		 {  
			  redirect(base_url() . 'welcome/login');  
		 }  
	}  
	function logout()  
	{  
		 $this->session->unset_userdata('username');  
		 redirect(base_url() . 'welcome/login');  
	}  


			


//Alldata


function Alldata(){  
	if($this->session->userdata('username') != '')  
	{  
	   
	   $this->load->view('header');
	   $this->load->view('navbar');
	   $this->load->view('over/Alldata'); 
	   $this->load->view('over/sectionscript'); 
	   
	   $this->load->view('footer'); 
	}  
	else  
	{  
		 redirect(base_url() . 'welcome/login');  
	}  
} 

public function create() 
{

	$validator = array('success' => false, 'messages' => array());

	$config = array(
	array(
	'field' => 'fname',
	'label' => 'First Name',
	'rules' => 'trim|required'
	),
	
	array(
	'field' => 'contact',
	'label' => 'Contact',
	'rules' => 'trim|required|integer'	            
	)
	);

	$this->form_validation->set_rules($config);
	$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

	if($this->form_validation->run() === true) {

		$createMember = $this->ManageModel->create(); 

		if($createMember === true) {
			$validator['success'] = true;
			$validator['messages'] = "Successfully added";
		} else {
			$validator['success'] = false;
			$validator['messages'] = "Error while updating the infromation";
		}			
	} 
	else {
		$validator['success'] = false;
		foreach ($_POST as $key => $value) {
			$validator['messages'][$key] = form_error($key);	
		}			
	}

	echo json_encode($validator);
}

public function fetchMemberData() 
{
	$result = array('data' => array());

	$data = $this->ManageModel->fetchMemberData();
	foreach ($data as $key => $value) {
		$name = $value['fname'] . ' ' . $value['lname'];
		
		// button
		$buttons = '		
		  <a type="button" onclick="editMember('.$value['id'].')" data-toggle="modal" data-target="#editMemberModal" class="btn btn-info fas fa-edit item_edit btn-sm"></a>
		<a type="button" onclick="removeMember('.$value['id'].')" data-toggle="modal" data-target="#removeMemberModal"  class="btn btn-danger fas fa-trash-alt item_delete btn-sm"></a>';

		$result['data'][$key] = array(
			$name,
			$value['age'],
			$_REQUEST['agecount'],
			$value['contact'],
			$value['address'],
			$buttons
		);
	} // /foreach

	echo json_encode($result);
}

public function getSelectedMemberInfo($id) 
{
	if($id) {
		$data = $this->ManageModel->fetchMemberData($id);
		echo json_encode($data);
	}
}

public function edit($id = null) 
{
	if($id) {
		$validator = array('success' => false, 'messages' => array());

		$config = array(
		array(
		'field' => 'editFname',
		'label' => 'First Name',
		'rules' => 'trim|required'
		),	
		array(
		'field' => 'editContact',
		'label' => 'Contact',
		'rules' => 'trim|required|integer'	            
		)
		);

		$this->form_validation->set_rules($config);
	$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

		if($this->form_validation->run() === true) {

			$editMember = $this->ManageModel->edit($id); 

			if($editMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Successfully updated";
			} else {
				$validator['success'] = false;
				$validator['messages'] = "Error while updating the infromation";
			}			
		} 
		else {
			$validator['success'] = false;
			foreach ($_POST as $key => $value) {
				$validator['messages'][$key] = form_error($key);	
			}			
		}

		echo json_encode($validator);
	}
}

public function remove($id = null)
{
	if($id) {
		$validator = array('success' => false, 'messages' => array());

		$removeMember = $this->ManageModel->remove($id);
		if($removeMember === true) {
			$validator['success'] = true;
			$validator['messages'] = "Successfully removed";
		}
		else {
			$validator['success'] = true;
			$validator['messages'] = "Successfully removed";
		}

		echo json_encode($validator);
	}
}

//Alldata
}






























		
		

    


