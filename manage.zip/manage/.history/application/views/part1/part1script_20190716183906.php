

<script type="text/javascript">
          // table_search(search,tr,indexSearch='0')




    $(document).ready(function(){      
       
        show_product(); //call function show all product
         
       

    

          
        //function show all product
        function show_product(){
            $.ajax({
                type  : 'ajax',
                url   : '<?php echo site_url('welcome/part_data')?>',
                async : true,
                dataType : 'json',
                success : function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        html += '<tr>'+
                                '<td>'+data[i].id+'</td>'+
                                '<td>'+data[i].name+'</td>'+
                                '<td>'+data[i].gender+'</td>'+
                                '<td>'+data[i].Part+'</td>'+
                                

                                '<td style="text-align:right;">'+
                                    '<a href="<?php echo site_url();?>welcome/view/'+data[i].id+'" class="btn btn-success fas  fa-eye view_part" data-id="'+data[i].id+'" data-product_name="'+data[i].name+'" data-price="'+data[i].gender+'"   data-Part="'+data[i].Part +'"></a>'+' '+
                                    
                                    '<a href="javascript:void(0);" class="btn btn-info fas fa-edit item_edit" data-id="'+data[i].id+'" data-name="'+data[i].name+'" data-gender="'+data[i].gender +'"  data-Part="'+data[i].Part +'"></a>'+' '+
                                    
                                    '<a href="javascript:void(0);" class="btn btn-danger fas fa-trash-alt item_delete" data-id="'+data[i].id+'"></a>'+
                                    '</td>'+
                                '</tr>';
                    }
                    $('#show_data').html(html);
                }
 
            });
        }
 

          //Save product
          $('#btn_save').on('click',function(){
            var name = $('#name').val();
            var gender = $('#gender').val();
            var Part        = $('#Part').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('welcome/save_data')?>",
                dataType : "JSON",
                data : {name:name , gender:gender, Part:Part},
                success: function(data){
                    $('[name="name"]').val("");
                    $('[name="gender"]').val("");
                    $('[name="Part"]').val("");
                    $('#Modal_Add').modal('hide');
                    show_product();
                }
            });
            return false;
        });




 //get data for update record
         $('#show_data').on('click','.item_edit',function(){
            var id = $(this).data('id');
            var name = $(this).data('name');
            var gender        = $(this).data('gender');
            var Part =      $(this).data('part');

            
            $('#Modal_Edit').modal('show');
            $('[name="id_edit"]').val(id);
            $('[name="name_edit"]').val(name);
            $('[name="gender_edit"]').val(gender);
            $('[name="Part_edit"]').val(Part);
            

        });
 
        //update record to database
         $('#btn_update').on('click',function(){
            var id = $('#id_edit').val();
            var name = $('#name_edit').val();
            var gender        = $('#gender_edit').val();
            var Part        = $('#Part_edit').val();

            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('welcome/update')?>",
                dataType : "JSON",
                data : {id:id , name:name, gender:gender, Part:Part},
                success: function(data){
                    $('[name="id_edit"]').val("");
                    $('[name="name_edit"]').val("");
                    $('[name="gender_edit"]').val("");
                    $('[name="Part_edit"]').val("");

                    $('#Modal_Edit').modal('hide');
                    show_product();
                }
            });
            return false;
        });
 








         $('#show_data').on('click','.item_delete',function(){
            var id = $(this).data('id');
             
            $('#Modal_Delete').modal('show');
            $('[name="id_delete"]').val(id);
        });
 
        //delete record to database
         $('#btn_delete').on('click',function(){
            var id = $('#id_delete').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('welcome/delete')?>",
                dataType : "JSON",
                data : {id:id},
                success: function(data){
                    $('[name="id_delete"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_product();
                }
            });
            return false;
        });

// PAGINATION



 
    });

   
 
</script>