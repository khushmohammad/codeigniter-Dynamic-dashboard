 <div class="row mb-3" style="padding: 15px;">
                <div class="col-xl-3 col-sm-6 py-2">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body bg-success">
                            <div class="rotate">
                                <i class="fa fa-user fa-4x"> Total </i>
                            
                            <h6 class="text-uppercase"></h6>
                            
                            </div>
                        </div>
                    </div>
                </div>
              
               
</div>
<div class="part1table" style="padding:15px">



</div>  

<script>

</script>
