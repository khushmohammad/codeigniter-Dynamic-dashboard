<div class="container">
  <div class="input-group date">
      <input type="text" class="form-control" id="datepicker" placeholder="MM/DD/YYYY">
  </div>
</div>
