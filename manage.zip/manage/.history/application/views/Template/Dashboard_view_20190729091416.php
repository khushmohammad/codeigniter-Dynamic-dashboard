<input id="datepicker" width="276" />
    <script>
        $('#datepicker').datepicker();
    </script>