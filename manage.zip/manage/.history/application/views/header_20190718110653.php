<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Simple Sidebar</title>

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
  <link href="<?php echo site_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo site_url(); ?>assets/datatables/datatables.min.css">


    

  <!-- Custom styles for this template -->
  <link href="<?php echo site_url(); ?>assets/css/simple-sidebar.css" rel="stylesheet">
  

  <script src="<?php echo site_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
     

  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
   

  <script src="<?php echo site_url(); ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="<?php echo site_url(); ?>assets/datatables/datatables.min.js"></script>
	<!-- custom js -->
  <script type="text/javascript" src="<?php echo site_url(); ?>assets/js/home.js"></script>
  




  
</head>

<body>

  
