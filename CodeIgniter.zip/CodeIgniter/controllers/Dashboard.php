<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	private $userId;

	function __construct(){
        parent::__construct();
			  
		$this->load->model('DashboardModal');
		$this->logged_in();
		$this->userId = $this->session->userdata('U_USERNAME');
		$userId = $this->session->userdata('U_USERNAME');	
      }
	// check log in  function  
	private function logged_in()
    {
        if( ! $this->session->userdata('authenticated')){
            redirect('Login');			
        }
		
    } 
	
	//dashboard view function
	
	public function index()
	{			
		$this->load->view('DashHeader');
		$this->load->view('Dashboard_view');
		$this->load->view('Footer');
	}	
	
	//START  VIEW DATA  
	//site user view
	//*use this for json  header('Content-Type: application/json');*/
	public function users()
	{		
		$this->load->view('DashHeader');
		$this->load->view('Site_View/Users_view');
		$this->load->view('Footer');
	}
	
	function User_ViewAjax()	
	{
			
		$this->datatables->select("U_ID, U_USERNAME,U_PASSWORD, U_EMAIL, U_CONTACT, U_ADDRESS, U_COUNTRY, U_STATE, U_CITY ,U_PINCODE,U_ACTIVE ")
		->from('dash_users');
		echo $this->datatables->generate();
	   
	}
	
	//END  VIEW DATA  
	//site user view
}
