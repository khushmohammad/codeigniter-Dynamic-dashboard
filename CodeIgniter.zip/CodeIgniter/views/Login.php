<div class="page login-page">
      <div class="container">
        <div class="form-outer text-center d-flex align-items-center">
          <div class="form-inner">
            <div class="logo text-uppercase"><span>Vilayat</span><strong class="text-primary">Dashboard</strong></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>           
			 <form method="POST" class="text-left form-validate" enctype="multipart/form-data" >
              <div class="form-group-material">
                <input id="login-username" type="text" name="U_USERNAME" required data-msg="Please enter your username" class="input-material" placeholder="Username">
                <label for="login-username" class="label-material"></label>
              </div>
              <div class="form-group-material">
                <input id="login-password" type="password" name="U_PASSWORD" required data-msg="Please enter your password" class="input-material" placeholder="Password">
                 <label for="login-password" class="label-material"></label> 
              </div>
              <div class="form-group text-center">
			  <input id="U_LOGIN" type="submit" class="btn btn-primary" value="Login" />               
              </div>
            </form><a href="#" class="forgot-pass">Forgot Password?</a><small>Do not have an account? </small><a href="index.php" class="signup">Signup</a>
          </div>
          <div class="copyrights text-center">
            <p>Design by <a href="#" class="external">Vilayat</a></p>
            
          </div>
        </div>
      </div>
    </div>
	
<script>

</script>	