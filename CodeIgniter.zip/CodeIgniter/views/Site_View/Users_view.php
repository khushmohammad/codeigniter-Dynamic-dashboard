<?php 
 $url = $this->uri->uri_string();
 ?>
 <style>

 </style>
<div class="userViewDataTable">
		<div class="addbutton">
			<p style="float: right;color: #8c8c8c ;"><?= ucfirst($url) ; ?> </p>
			<a href="#" id="add" type="button" class="btn btn-primary ButtonId" data-toggle="modal" data-target="#User_ViewAddEditModal">Add</a>   
		</div>
		<table class="display table table-striped table-bordered nowrap" id="datatables" width="100%" cellspacing="0" >
			<thead>
				<tr>
					<th data-class="expand" width="10%">ID</th>
					<th data-class="expand" >NAME</th>
					<th data-class="expand" >PASSWORD</th>
					<th data-class="expand">EMAIL</th>
					<th data-class="expand">CONTACT</th>
					<th data-class="expand">ADDRESS</th>
					<th data-class="expand">ACTIVE</th>
					<th data-hide="phone,tablet" width="10%">ACTION</th>
				</tr>
			</thead>
			<tbody>			
			</tbody>
		</table>	
</div>
<script type="text/javascript">
    //datatable view data
	$(document).ready(function() {		
		var DataTableObject=[
			{ data: 'U_ID' ,className:"all"},
			{ data: 'U_USERNAME' ,className:"all"},
			{ data: 'U_PASSWORD'},
			{ data: 'U_EMAIL'},
			{ data: 'U_CONTACT'},
			{ data: null , 'searchable': false ,
			 render : function (data, type, dataToSet) {
			return data.U_ADDRESS + ", " + data.U_CITY + "<br>" + data.U_STATE + ", " + data.U_COUNTRY + "<br>"+ data.U_PINCODE;
			}},
			{ data: 'U_ACTIVE'},
			{ data: null, "orderable": false, 'searchable': false, className:"all", 
				render: function( data, type, row) {
					sysid=data['U_ID'];				
					return   '<div class="dropdown" >'
								+'	<button type="button" class="btn dropdown-toggle" data-toggle="dropdown">'
								+	'</button>'
								+	'<div class="dropdown-menu">'
								+	  '<a id="Edit" class="dropdown-item ButtonId" data-id="'+sysid+'" data-toggle="modal" data-target="#User_ViewAddEditModal" href="#">Edit</a>'
								+	  '<a class="dropdown-item" href="#">Delete</a>'								
								+	'</div>'
								 +' </div>';
    
				}
			}
			];
		
	    var table = $('#datatables').DataTable( {       
		"processing": true,
        "serverSide": true,
		'responsive': true,		
		'scrollX':true,
		'scrollY':'320px',
		'scrollCollapse': true,		
		'dataType': 'json',				
		 columns: DataTableObject,		
        "ajax": {
            "url": "<?= base_url(); ?>Dashboard/User_ViewAjax",
            "type": "POST"
        },
		
		});
		
});

 //datatable view data end
 //validation start

	//validation end
	
	
</script>
<div class="modal fade" id="User_ViewAddEditModal" tabindex="-1" role="dialog" aria-labelledby="User_ViewAddEditModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
     <form id="userFormAddEditValidate" action="javascript:void(0);" method="POST" class="text-left userFormAddEdit" enctype="multipart/form-data">	
      <div class="modal-header">
        <h5 class="modal-title" id="User_ViewAddEditModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
		<div class="row">
		 <div class="col-md-6" >
					<section class="form-group">
					  <label>Name</label>
					  <input type="text" name="U_USERNAME" placeholder="Name" class="form-control form-control-sm">
					</section>
					<section class="form-group">
					  <label class="control-label">Gender</label>
						<select name="U_GENDER" id="U_GENDER" class="selectpicker form-control form-control-sm" data-style="btn-white btn-sm" data-live-search="true">
						 <option value="">Select</option>
						  <option value="Male">Male</option>
						  <option  value="Female">Female</option>								 
						</select>
					</section> 
					 <section class="form-group">
					  <label>country</label>
					  <input type="text" name="U_COUNTRY" placeholder="country" class="form-control form-control-sm">
					</section>
				</div>
				<div class="col-md-6" >
					<section class="form-group">
					  <label>address</label>
					  <input type="text" name="U_ADDRESS" placeholder="address" class="form-control form-control-sm" >
					</section>
					 <section class="contact form-group">
					  <label>contact</label>
					  <input type="text" name="U_CONTACT"  id="U_CONTACT" placeholder="contact" class="form-control form-control-sm" >
					</section>
					 <section class="form-group">
					  <label>email</label>
					  <input type="text" name="U_EMAIL " placeholder="email" class="form-control form-control-sm" >
					</section>
					 <section class="form-group">
					  <label>password</label>
					  <input type="text" name=" U_PASSWORD" placeholder="password" class="form-control form-control-sm">
					</section>
					</div>
			    </div>				
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button  type="submit" class="btn btn-primary">Save</button> 
      </div>
     </form> 
    </div>
  </div>
</div>
