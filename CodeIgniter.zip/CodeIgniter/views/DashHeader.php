<?php 
$this->load->view('Header');
$this->load->view('Nav');
?>