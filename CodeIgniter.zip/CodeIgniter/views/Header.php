<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bootstrap Dashboard by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?= site_url();?>assets/vendor/bootstrap/css/bootstrap.min.css">
		
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?= site_url();?>assets/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="<?= site_url();?>assets/css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
	
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="<?= site_url();?>assets/css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="<?= site_url();?>assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
	
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?= site_url();?>assets/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?= site_url();?>assets/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?= site_url();?>assets/img/favicon.ico">	
	<!-- datatables--->
	 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"/>
	 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css"/>
	 <!-- selectpicker  -->
	 <link rel="stylesheet" href="<?= site_url();?>assets/css/bootstrap-select.min.css">
	  <!-- telephone flag  -->
	 <link rel="stylesheet" href="<?= site_url();?>assets/css/intlTelInput.min.css">

<!-- Latest compiled and minified JavaScript -->

	<!-- jquery and script--->
	<script src="<?= site_url();?>assets/vendor/jquery/jquery.min.js"></script>
	<script src="<?= site_url();?>assets/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="<?= site_url();?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= site_url();?>assets/js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="<?= site_url();?>assets/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="<?= site_url();?>assets/vendor/chart.js/Chart.min.js"></script>
    <script src="<?= site_url();?>assets/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?= site_url();?>assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
	<!-- selectpicker -->
	<script src="<?= site_url();?>assets/js/bootstrap-select.min.js"></script>
	  <!-- telephone flag  -->
	<script src="<?= site_url();?>assets/js/intlTelInput.min.js"></script> 	 	
	<!-- Main File-->
    <script src="<?= site_url();?>assets/js/front.js"></script>
  </head>
  <body>
  