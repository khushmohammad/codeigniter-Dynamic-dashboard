<div id = "haha">           

		<script src="<?php echo base_url('assets/test/js-image-slider.js')?>"></script>
	
		<link href="<?php echo base_url('assets/test/js-image-slider.css')?>" rel="stylesheet">

		<div id="sliderFrame">
			<div id="slider">
				<a href="" target="_blank">
					<img src="<?php echo base_url('images/sekolah.jpg'); ?>" alt="#cap1" />
				</a>
				  <img src="<?php echo base_url('images/la.jpg'); ?>" class="img-rounded" alt="Laboratory" width="304" height="236"> 

				<img id="image1" src="<?php echo base_url('images/kerusi.jpg'); ?>" alt="Welcome to Our Class."/>
				<img id="image1" src="<?php echo base_url('images/field.jpg'); ?>" alt="Many type of classes."/>
				<img id="image1" src="<?php echo base_url('images/canteen.jpg'); ?>" />
			</div>
			<div style="display: none;">
				<div id="cap1">
					Welcome to <a href="http://www.google.com/">SEMSAS</a>.
				</div>
				<div id="cap2">
					<em>HTML</em> caption. Link to <a href="http://www.google.com/">Google</a>.
				</div>
			</div>
		</div>


</div>
